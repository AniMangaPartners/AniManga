'use strict';

angular.module('streama').controller('settingsCtrl', ['$scope', 'apiService', 'modalService', '$rootScope', function ($scope, apiService, modalService, $rootScope) {

}]);




