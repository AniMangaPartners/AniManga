package streama

class SubtitlesRequest {

  String episode
  String query
  String season
  String subLanguageId
}
