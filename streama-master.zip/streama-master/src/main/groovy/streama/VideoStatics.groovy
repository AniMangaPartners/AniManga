package streama

class VideoStatus {
  static public String COMPLETED = 'completed'
  static public String VIEWING = 'viewing'
  static public String UNVIEWED = 'unviewed'
}
